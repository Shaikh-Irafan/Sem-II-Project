<?php
session_start();

// Initialize counter if not set
if (!isset($_SESSION['visit_count'])) {
    $_SESSION['visit_count'] = 1;
} else {
    $_SESSION['visit_count']++;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Visit Counter</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .counter-box {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        h1 {
            color: #333;
        }
        .count {
            font-size: 2em;
            color: #4a90e2;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="counter-box">
    <h1>Welcome!</h1>
    <p class="count">You have visited this page <strong><?= $_SESSION['visit_count'] ?></strong> times.</p>
</div>

</body>
</html> 