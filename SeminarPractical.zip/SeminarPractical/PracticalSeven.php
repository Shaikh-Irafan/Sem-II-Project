<!DOCTYPE html>
<html>
<head>
  <title>Simple Digital Clock</title>
  <style>
    body {
      background-color: #202124;
      color: #00ffcc;
      font-family: 'Courier New', monospace;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .clock {
      font-size: 48px;
      border: 2px solid #00ffcc;
      padding: 30px 50px;
      border-radius: 10px;
      background-color: #000000;
      box-shadow: 0 0 20px #00ffcc;
    }
  </style>
</head>
<body>

  <div class="clock">
    <?php
      function showTime() {
        date_default_timezone_set("Asia/Kolkata"); // Set your timezone
        return date("H:i:s");
      }

      echo showTime();
    ?>
  </div>

</body>
</html>
